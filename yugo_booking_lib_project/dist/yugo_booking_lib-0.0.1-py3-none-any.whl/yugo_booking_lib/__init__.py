# src/yugo_booking_lib/__init__.py

"""
Yugo booking helper library.
Provides BookingPrice class for nights + price calculations.
"""
