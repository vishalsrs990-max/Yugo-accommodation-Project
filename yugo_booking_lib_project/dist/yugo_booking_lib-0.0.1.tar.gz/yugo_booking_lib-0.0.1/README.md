# yugo-booking-lib-vishal

Small Python library for Yugo-style accommodation bookings.

It provides a `BookingPrice` class that:
- calculates number of nights between two dates
- calculates total price with optional tax and fixed fee
